# VisionFirst

**An open-source, smartphone-based vision screening toolkit for NGO eye camps.**

VisionFirst is being built to help NGO eye-care camps triage patients quickly and consistently, using nothing more than a basic smartphone — no extra hardware required.

## Status: In Development 🚧

This project is in active development. The plan, architecture, and roadmap below are finalized; implementation is underway. Watch/star this repo to follow progress, or reach out — see [Contact](#contact) below — if you run eye camps and want to help shape the tool.

## What VisionFirst Will Do

VisionFirst has three components:

1. **Digital Visual Acuity Test** — A smartphone-based test to screen visual acuity in the field, without specialized equipment.
2. **Bilingual Triage Questionnaire (Hindi/English)** — A structured questionnaire to help camp staff quickly triage patients and flag cases needing referral.
3. **Analytics Dashboard (Streamlit)** — A dashboard for camp organizers to track screening results, follow up on flagged cases, and understand camp-level outcomes over time.

Camera-based distance estimation was considered and intentionally scoped out for the initial version, to keep the tool simple and reliable on basic devices.

## Why

Many NGO eye camps in India operate with limited digital tooling for triage and follow-up. VisionFirst aims to be a free, lightweight, open-source option that camp staff can run on phones they already have.

## Roadmap

See [docs/execution-plan.md](docs/execution-plan.md) for the detailed 8-week execution plan.

## Contact

Built by **Aaditya Kumar Ahirwar**, independent researcher, OZTX Research Team.
Reach out via GitHub or the contact details in outreach correspondence.

## Contributing

VisionFirst is being developed with the intent of building a small team around it. If you're interested in contributing — engineering, design, or domain expertise in eye care — open an issue or get in touch.

## License

License to be finalized before first release (open-source).
