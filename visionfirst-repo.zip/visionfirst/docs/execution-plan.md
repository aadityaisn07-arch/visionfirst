# VisionFirst — 8-Week Execution Plan

## Component overview

| Component | Purpose |
|---|---|
| Digital Visual Acuity Test | Smartphone-based visual acuity screening |
| Bilingual Triage Questionnaire | Hindi/English questionnaire for rapid patient triage |
| Analytics Dashboard | Streamlit dashboard for camp organizers to track & follow up on cases |

## Scope decisions

- Camera-based distance estimation: **out of scope** for v1 — adds hardware/calibration complexity without clear reliability gains on basic phones.
- Target device: any basic Android smartphone, no additional hardware.

## Phases

1. **Weeks 1–2:** Finalize visual acuity test design and validate against standard charts; draft triage questionnaire content in Hindi and English.
2. **Weeks 3–4:** Build the acuity test as a working app/web tool; pilot the questionnaire with camp staff feedback.
3. **Weeks 5–6:** Build the analytics dashboard (Streamlit); wire up data flow from test + questionnaire into the dashboard.
4. **Weeks 7–8:** End-to-end pilot at a small camp (or simulated run), fix issues, prepare for broader NGO outreach and handoff documentation.

## Team

- Aaditya Kumar Ahirwar — lead
- Potential collaborators: Ashutosh, Daksh, Apoorva, Tanishk
- Advisory: Saurabh Ahirwar (PhD chemistry researcher)

## Status

Planning complete. Implementation starting.
