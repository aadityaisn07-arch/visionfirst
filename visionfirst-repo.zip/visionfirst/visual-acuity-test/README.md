# Digital Visual Acuity Test

Smartphone-based visual acuity screening component. Implementation in progress.
