# Bilingual Triage Questionnaire (Hindi/English)

Structured questionnaire for rapid patient triage at eye camps. Implementation in progress.
